import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Search, Heart, ShoppingBag, User, LogOut, ChevronDown, Sparkles, Menu, X, Command } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';
import { CommandPalette } from './CommandPalette';
import { AIAssistantModal } from './AIAssistantModal';

interface NavbarProps {
  onCartClick: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onCartClick }) => {
  const { user, logout, isAdmin, isBoutique, isDesigner } = useAuth();
  const { cartItems } = useCart();
  const { wishlistItems } = useWishlist();

  const [commandPaletteOpen, setCommandPaletteOpen] = useState(false);
  const [aiAssistantOpen, setAiAssistantOpen] = useState(false);
  const [showProfileDropdown, setShowProfileDropdown] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navigate = useNavigate();
  const profileRef = useRef<HTMLDivElement>(null);

  // Close dropdowns on outside click
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (profileRef.current && !profileRef.current.contains(event.target as Node)) {
        setShowProfileDropdown(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const totalCartCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <>
      <nav className="glass-nav sticky top-0 z-40 w-full px-6 py-3.5 flex items-center justify-between font-sans">
        
        {/* Left: Brand Logo & Navigation */}
        <div className="flex items-center gap-10">
          <div onClick={() => navigate('/')} className="flex items-center gap-2 group cursor-pointer">
            <span className="text-2xl font-serif font-bold tracking-widest text-gray-900 group-hover:text-[#C79A4A] transition-colors">
              ABespoke
            </span>
            <span className="text-[9px] uppercase tracking-widest text-[#C79A4A] font-sans font-bold border border-[#C79A4A]/30 px-1.5 py-0.5 rounded">
              HAUTE COUTURE
            </span>
          </div>

          {/* Desktop Categories */}
          <div className="hidden lg:flex items-center gap-8 font-sans font-medium text-xs tracking-widest text-gray-600 uppercase">
            <Link to="/catalog?gender=men" className="hover:text-gray-900 transition-colors luxury-hover-line">Men</Link>
            <Link to="/catalog?gender=women" className="hover:text-gray-900 transition-colors luxury-hover-line">Women</Link>
            <Link to="/catalog?category-[#C79A4A]" className="hover:text-gray-900 transition-colors text-[#C79A4A] font-semibold flex items-center gap-1">
              <Sparkles className="w-3 h-3" /> Atelier Collections
            </Link>
          </div>
        </div>

        {/* Center: Command Palette / Floating Search Trigger */}
        <div className="hidden md:flex items-center flex-1 max-w-md mx-6">
          <button
            onClick={() => setCommandPaletteOpen(true)}
            className="w-full flex items-center justify-between bg-[#F5F3EF] hover:bg-white hover:border-[#C79A4A]/50 border border-gray-200/80 rounded-full px-4 py-2 text-xs text-gray-400 transition-all shadow-inner group cursor-pointer"
          >
            <div className="flex items-center gap-2.5">
              <Search className="w-4 h-4 text-gray-400 group-hover:text-[#C79A4A] transition-colors" />
              <span className="font-medium text-gray-500">Search luxury collections, ateliers...</span>
            </div>
            <div className="flex items-center gap-1 font-mono text-[10px] bg-white border border-gray-200 px-2 py-0.5 rounded-full text-gray-500 shadow-xs">
              <Command className="w-3 h-3" />
              <span>K</span>
            </div>
          </button>
        </div>

        {/* Right: Actions */}
        <div className="flex items-center gap-5">
          
          {/* AI Virtual Stylist Button */}
          <button
            onClick={() => setAiAssistantOpen(true)}
            className="hidden sm:flex items-center gap-1.5 bg-gradient-to-r from-gray-900 to-gray-800 hover:from-[#C79A4A] hover:to-[#b08439] text-white px-3.5 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider transition-all shadow-sm cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#C79A4A] group-hover:text-white" />
            <span>AI Stylist</span>
          </button>

          {/* User Profile */}
          <div ref={profileRef} className="relative">
            <button
              onClick={() => setShowProfileDropdown(!showProfileDropdown)}
              className="flex items-center gap-1 p-1 hover:text-[#C79A4A] transition-colors cursor-pointer"
            >
              <div className="w-8 h-8 rounded-full bg-gray-100 border border-gray-200 flex items-center justify-center text-gray-700 font-bold text-xs uppercase">
                {user ? user.name.charAt(0) : <User className="w-4 h-4" />}
              </div>
              <ChevronDown className="w-3.5 h-3.5 text-gray-400 hidden sm:block" />
            </button>

            {showProfileDropdown && (
              <div className="absolute right-0 top-11 w-60 bg-white border border-gray-150 shadow-2xl rounded-2xl p-2 z-50 text-xs font-sans animate-fadeIn">
                {user ? (
                  <div>
                    <div className="px-4 py-3 border-b border-gray-100">
                      <p className="font-bold text-gray-900 truncate">{user.name}</p>
                      <p className="text-[10px] text-gray-400 truncate">{user.email}</p>
                      <span className="inline-block mt-1.5 bg-[#C79A4A]/10 text-[#C79A4A] border border-[#C79A4A]/30 text-[9px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider">
                        {user.role} Account
                      </span>
                    </div>
                    <div className="flex flex-col py-1 font-medium">
                      {user.role === 'user' && (
                        <>
                          <Link to="/dashboard" onClick={() => setShowProfileDropdown(false)} className="px-4 py-2 hover:bg-[#F5F3EF] hover:text-[#C79A4A] rounded-xl transition-colors">My Profile</Link>
                          <Link to="/dashboard?tab=orders" onClick={() => setShowProfileDropdown(false)} className="px-4 py-2 hover:bg-[#F5F3EF] hover:text-[#C79A4A] rounded-xl transition-colors">My Orders</Link>
                        </>
                      )}
                      {isBoutique && (
                        <Link to="/boutique" onClick={() => setShowProfileDropdown(false)} className="px-4 py-2 hover:bg-[#F5F3EF] text-[#C79A4A] font-semibold rounded-xl transition-colors">Boutique Dashboard</Link>
                      )}
                      {isDesigner && (
                        <Link to="/designer" onClick={() => setShowProfileDropdown(false)} className="px-4 py-2 hover:bg-[#F5F3EF] text-[#C79A4A] font-semibold rounded-xl transition-colors">Designer Dashboard</Link>
                      )}
                      {isAdmin && (
                        <Link to="/admin" onClick={() => setShowProfileDropdown(false)} className="px-4 py-2 hover:bg-[#F5F3EF] text-[#C79A4A] font-semibold rounded-xl transition-colors">Admin Dashboard</Link>
                      )}
                      <button
                        onClick={() => {
                          logout();
                          setShowProfileDropdown(false);
                        }}
                        className="w-full text-left px-4 py-2 text-red-600 hover:bg-red-50 rounded-xl flex items-center gap-2 transition-colors font-semibold mt-1"
                      >
                        <LogOut className="w-3.5 h-3.5" /> Logout
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="p-4 text-center space-y-3">
                    <p className="text-gray-500 font-light text-[11px] leading-relaxed">Sign in to access custom fitting designs & personal recommendations</p>
                    <Link
                      to="/login"
                      onClick={() => setShowProfileDropdown(false)}
                      className="block w-full py-2.5 bg-gray-900 hover:bg-[#C79A4A] text-white rounded-xl font-bold tracking-wider text-[10px] uppercase transition-all shadow-md"
                    >
                      Login / Sign Up
                    </Link>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Wishlist */}
          <Link to="/dashboard?tab=wishlist" className="relative p-1 hover:text-[#C79A4A] transition-colors">
            <Heart className="w-5 h-5 text-gray-800 hover:text-[#C79A4A]" />
            {wishlistItems.length > 0 && (
              <span className="absolute -top-1 -right-1 bg-red-600 text-white text-[9px] w-4 h-4 rounded-full flex items-center justify-center font-bold">
                {wishlistItems.length}
              </span>
            )}
          </Link>

          {/* Cart */}
          <button onClick={onCartClick} className="relative p-1 hover:text-[#C79A4A] transition-colors cursor-pointer">
            <ShoppingBag className="w-5 h-5 text-gray-800 hover:text-[#C79A4A]" />
            {totalCartCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-[#C79A4A] text-white text-[9px] w-4 h-4 rounded-full flex items-center justify-center font-bold animate-pulse">
                {totalCartCount}
              </span>
            )}
          </button>

          {/* Mobile menu trigger */}
          <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className="lg:hidden p-1">
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Drawer */}
        {mobileMenuOpen && (
          <div className="absolute top-[64px] left-0 w-full bg-white border-b border-gray-200 shadow-2xl p-6 flex flex-col gap-4 lg:hidden z-40 text-xs font-sans tracking-wider uppercase font-semibold">
            <Link to="/catalog?gender=men" onClick={() => setMobileMenuOpen(false)} className="py-2 border-b border-gray-100">Men</Link>
            <Link to="/catalog?gender=women" onClick={() => setMobileMenuOpen(false)} className="py-2 border-b border-gray-100">Women</Link>
            <button
              onClick={() => { setMobileMenuOpen(false); setCommandPaletteOpen(true); }}
              className="w-full flex items-center justify-between bg-[#F5F3EF] p-3 rounded-xl text-gray-600 text-left mt-1"
            >
              <span>Search ABespoke Catalog...</span>
              <Search className="w-4 h-4 text-gray-400" />
            </button>
          </div>
        )}
      </nav>

      {/* Command Palette Modal */}
      <CommandPalette
        isOpen={commandPaletteOpen}
        onClose={() => setCommandPaletteOpen(false)}
        onOpenAI={() => setAiAssistantOpen(true)}
      />

      {/* AI Assistant Modal */}
      <AIAssistantModal
        isOpen={aiAssistantOpen}
        onClose={() => setAiAssistantOpen(false)}
      />
    </>
  );
};

export default Navbar;
