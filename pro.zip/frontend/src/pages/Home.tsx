import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowRight, Sparkles, ShieldCheck, Truck, RefreshCw, ChevronDown } from 'lucide-react';
import ProductCard from '../components/ProductCard';
import { productsAPI } from '../services/api';

export const Home: React.FC = () => {
  const navigate = useNavigate();
  const [newArrivals, setNewArrivals] = useState<any[]>([]);
  const [trending, setTrending] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchHomeData = async () => {
      try {
        const arrivalData = await productsAPI.getProducts({ sort: 'new-arrivals', limit: 4 });
        const trendingData = await productsAPI.getProducts({ sort: 'recommended', limit: 4 });
        const arr = Array.isArray(arrivalData) ? arrivalData : (arrivalData?.products || []);
        const tr = Array.isArray(trendingData) ? trendingData : (trendingData?.products || []);
        setNewArrivals(arr);
        setTrending(tr);
      } catch (err) {
        console.error('Failed to load home page products:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchHomeData();
  }, []);

  const categories = [
    {
      name: 'Bridal & Couture Sarees',
      image: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=600&auto=format&fit=crop&q=80',
      link: '/catalog?gender=women&category=Sarees',
      desc: 'Hand-woven pure silk & organza sarees'
    },
    {
      name: 'Flared Royal Lehengas',
      image: 'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?w=600&auto=format&fit=crop&q=80',
      link: '/catalog?gender=women&category=Lehengas',
      desc: 'Intricate zardozi & sequin craftsmanship'
    },
    {
      name: 'Contemporary Kurtis',
      image: 'https://images.unsplash.com/photo-1608748010899-18f300247112?w=600&auto=format&fit=crop&q=80',
      link: '/catalog?gender=women&category=Kurtis',
      desc: 'Refined modern silhouettes for everyday luxury'
    },
    {
      name: 'Bespoke Tailored Shirts',
      image: 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=600&auto=format&fit=crop&q=80',
      link: '/catalog?gender=men&category=Shirts',
      desc: 'Egyptian cotton & crisp linen formal shirts'
    },
    {
      name: 'Structured Tuxedo Blazers',
      image: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=600&auto=format&fit=crop&q=80',
      link: '/catalog?gender=men&category=Blazers',
      desc: 'Italian wool cut blazers & dinner jackets'
    },
    {
      name: 'Selvedge Denim Line',
      image: 'https://images.unsplash.com/photo-1542272604-787c3835535d?w=600&auto=format&fit=crop&q=80',
      link: '/catalog?gender=men&category=Jeans',
      desc: 'Raw indigo denim crafted with classic fit'
    }
  ];

  return (
    <div className="space-y-20 font-sans pb-16 bg-[#F5F3EF]">
      
      {/* 1. Cinematic Luxury Full-Screen Hero Section */}
      <div className="relative min-h-[85vh] w-full overflow-hidden bg-gray-950 flex items-center justify-center">
        {/* Background Editorial Image */}
        <img
          src="https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=1600&auto=format&fit=crop&q=80"
          alt="ABespoke Haute Couture Campaign"
          className="absolute inset-0 w-full h-full object-cover opacity-60 object-center transition-transform duration-[8000ms] hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/40 to-transparent" />

        {/* Hero Content */}
        <div className="relative z-10 max-w-7xl mx-auto px-6 md:px-12 w-full flex flex-col justify-center space-y-8 text-white">
          <div className="space-y-4 max-w-2xl">
            <span className="inline-flex items-center gap-2 bg-[#C79A4A]/20 text-[#C79A4A] border border-[#C79A4A]/40 px-3.5 py-1 rounded-full text-[10px] uppercase font-bold tracking-widest font-sans backdrop-blur-md">
              <Sparkles className="w-3.5 h-3.5" /> ATELIER CAMPAIGN 2026
            </span>

            <h1 className="font-serif text-4xl sm:text-6xl lg:text-7xl font-bold leading-none tracking-wide text-white">
              Couture Without <br />
              <span className="text-[#C79A4A] italic font-light">Compromise.</span>
            </h1>

            <p className="text-xs sm:text-sm text-gray-200 leading-relaxed font-light max-w-lg">
              Explore bespoke luxury garments from top fashion houses, verified designer labels, and master tailors. Precision fitting delivered to your doorstep.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-4 pt-2">
            <Link
              to="/catalog"
              className="bg-[#C79A4A] hover:bg-[#b08439] text-white font-bold px-8 py-4 rounded-xl uppercase tracking-wider text-xs flex items-center gap-2.5 transition-all shadow-xl hover:shadow-2xl cursor-pointer"
            >
              <span>Explore Collection</span>
              <ArrowRight className="w-4 h-4" />
            </Link>

            <Link
              to="/catalog?trending=true"
              className="bg-white/10 hover:bg-white/20 text-white border border-white/30 backdrop-blur-md font-bold px-7 py-4 rounded-xl uppercase tracking-wider text-xs transition-all cursor-pointer"
            >
              View Lookbook
            </Link>
          </div>
        </div>

        {/* Animated Scroll Indicator */}
        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1.5 text-gray-300 text-[10px] uppercase tracking-widest animate-bounce">
          <span>Scroll To Discover</span>
          <ChevronDown className="w-4 h-4 text-[#C79A4A]" />
        </div>
      </div>

      {/* 2. Curated Department Showcase */}
      <div className="max-w-7xl mx-auto px-6 space-y-10">
        <div className="text-center space-y-2 max-w-xl mx-auto">
          <span className="text-[10px] font-bold uppercase tracking-widest text-[#C79A4A]">Haute Couture Department</span>
          <h2 className="font-serif text-3xl md:text-4xl font-bold text-gray-900 tracking-wide">Curated Collections</h2>
          <p className="text-xs text-gray-500 font-light leading-relaxed">Discover hand-tailored luxury garments designed for grand weddings, formal galas, and timeless style statement.</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {categories.map((cat, idx) => (
            <div
              key={idx}
              onClick={() => navigate(cat.link)}
              className="glass-card glass-card-hover group cursor-pointer overflow-hidden p-3 flex flex-col space-y-4"
            >
              <div className="aspect-[4/5] w-full rounded-xl overflow-hidden bg-gray-100 relative">
                <img
                  src={cat.image}
                  alt={cat.name}
                  className="w-full h-full object-cover object-top transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute top-3 left-3 bg-black/60 backdrop-blur-md text-white text-[9px] font-bold uppercase tracking-widest px-2.5 py-1 rounded-full">
                  Atelier Choice
                </div>
              </div>
              
              <div className="px-2 pb-2 flex justify-between items-end">
                <div className="space-y-1">
                  <h3 className="font-serif text-lg font-bold text-gray-900 group-hover:text-[#C79A4A] transition-colors">{cat.name}</h3>
                  <p className="text-[11px] text-gray-500 font-light leading-snug">{cat.desc}</p>
                </div>
                <span className="text-[10px] text-[#C79A4A] font-bold uppercase tracking-widest flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                  Shop <ArrowRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 3. Promotional Luxury Offer Banner */}
      <div className="max-w-7xl mx-auto px-6">
        <div className="bg-gradient-to-r from-gray-950 via-gray-900 to-gray-950 text-white rounded-3xl p-8 md:p-14 flex flex-col lg:flex-row items-center justify-between gap-8 relative overflow-hidden border border-gray-800 shadow-2xl">
          <div className="space-y-4 max-w-xl z-10">
            <span className="inline-block bg-[#C79A4A]/20 text-[#C79A4A] border border-[#C79A4A]/40 px-3.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest">
              Exclusive Privilege Card Offer
            </span>
            <h2 className="font-serif text-3xl md:text-4xl font-bold leading-tight">
              Unlock Up To 30% Off <br />
              <span className="text-[#C79A4A]">Bespoke Order Checkout</span>
            </h2>
            <p className="text-xs text-gray-300 font-light leading-relaxed">
              Use luxury promo codes during checkout. Enjoy complimentary Express delivery, premium velvet packaging, and priority custom fitting support.
            </p>
            <div className="flex flex-wrap gap-3 text-xs font-sans pt-2">
              <span className="bg-white/10 backdrop-blur-md text-white border border-white/20 px-4 py-2 rounded-xl font-mono">
                Code: <strong className="text-[#C79A4A]">PREMIUM20</strong> (20% Off)
              </span>
              <span className="bg-white/10 backdrop-blur-md text-white border border-white/20 px-4 py-2 rounded-xl font-mono">
                Code: <strong className="text-[#C79A4A]">FESTIVE30</strong> (30% Off)
              </span>
            </div>
          </div>

          <div className="shrink-0 z-10">
            <button
              onClick={() => navigate('/catalog')}
              className="bg-[#C79A4A] hover:bg-[#b08439] text-white font-bold px-9 py-4 rounded-xl uppercase tracking-wider text-xs transition-all shadow-xl cursor-pointer"
            >
              Shop Atelier Collection
            </button>
          </div>
        </div>
      </div>

      {/* 4. Trending Collections Grid */}
      <div className="max-w-7xl mx-auto px-6 space-y-8">
        <div className="flex justify-between items-end">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-widest text-[#C79A4A]">Curated Weekly</span>
            <h2 className="font-serif text-2xl md:text-3xl font-bold text-gray-900 tracking-wide">Trending Now</h2>
          </div>
          <Link to="/catalog?trending=true" className="text-xs font-bold uppercase tracking-wider text-[#C79A4A] hover:text-gray-900 transition-colors flex items-center gap-1.5">
            <span>Explore All</span> <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

        {loading ? (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="skeleton-shimmer aspect-[3/4] rounded-2xl w-full" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            {trending.map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}
      </div>

      {/* 5. New Arrivals Drops */}
      {newArrivals.length > 0 && (
        <div className="max-w-7xl mx-auto px-6 space-y-8">
          <div className="flex justify-between items-end">
            <div>
              <span className="text-[10px] font-bold uppercase tracking-widest text-[#C79A4A]">Fresh Studio Drops</span>
              <h2 className="font-serif text-2xl md:text-3xl font-bold text-gray-900 tracking-wide">New Arrivals</h2>
            </div>
            <Link to="/catalog?sort=new-arrivals" className="text-xs font-bold uppercase tracking-wider text-[#C79A4A] hover:text-gray-900 transition-colors flex items-center gap-1.5">
              <span>View All Drops</span> <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            {newArrivals.map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      )}

      {/* 5. Brand Assurances */}
      <div className="bg-white border-y border-gray-200 py-16 px-6">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-10">
          <div className="flex flex-col items-center text-center space-y-3 font-sans">
            <div className="w-14 h-14 rounded-2xl bg-[#F5F3EF] border border-[#C79A4A]/30 flex items-center justify-center text-[#C79A4A]">
              <Truck className="w-6 h-6" />
            </div>
            <h3 className="font-serif text-lg font-bold text-gray-900">Complimentary Courier Transit</h3>
            <p className="text-xs text-gray-500 font-light max-w-xs leading-relaxed">
              Trackable express courier delivery on orders over Rs. 1,499 with insured tamper-proof packaging.
            </p>
          </div>

          <div className="flex flex-col items-center text-center space-y-3 font-sans">
            <div className="w-14 h-14 rounded-2xl bg-[#F5F3EF] border border-[#C79A4A]/30 flex items-center justify-center text-[#C79A4A]">
              <RefreshCw className="w-6 h-6" />
            </div>
            <h3 className="font-serif text-lg font-bold text-gray-900">15-Day Bespoke Guarantee</h3>
            <p className="text-xs text-gray-500 font-light max-w-xs leading-relaxed">
              Hassle-free doorstep return pick-up or size adjustment coordinate directly inside your dashboard.
            </p>
          </div>

          <div className="flex flex-col items-center text-center space-y-3 font-sans">
            <div className="w-14 h-14 rounded-2xl bg-[#F5F3EF] border border-[#C79A4A]/30 flex items-center justify-center text-[#C79A4A]">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <h3 className="font-serif text-lg font-bold text-gray-900">Verified Atelier Partners</h3>
            <p className="text-xs text-gray-500 font-light max-w-xs leading-relaxed">
              Every designer and boutique holds verified certification (`✓`) guaranteeing authentic luxury materials.
            </p>
          </div>
        </div>
      </div>

    </div>
  );
};

export default Home;
